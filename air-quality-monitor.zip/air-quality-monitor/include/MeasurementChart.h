#ifndef MEASUREMENT_CHART_H
#define MEASUREMENT_CHART_H

#include <gtkmm.h>
#include <vector>
#include "Measurement.h"

class MeasurementChart : public Gtk::DrawingArea {
public:
    MeasurementChart();
    virtual ~MeasurementChart();

    void setMeasurements(const std::vector<Measurement>& measurements);
    Measurement getMaxMeasurement() const;   // Funkcja zwracająca pomiar o największej wartości
    Measurement getMinMeasurement() const;   // Funkcja zwracająca pomiar o najmniejszej wartości
    double getAverageValue() const;

protected:
    bool on_draw(const Cairo::RefPtr<Cairo::Context>& cr) override;

private:
    std::vector<Measurement> m_measurements;

    void drawAxes(const Cairo::RefPtr<Cairo::Context>& cr, double width, double height);
    void drawLineChart(const Cairo::RefPtr<Cairo::Context>& cr, double width, double height);
};

#endif // MEASUREMENT_CHART_H
