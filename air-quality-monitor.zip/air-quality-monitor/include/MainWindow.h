#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <gtkmm/window.h>
#include <gtkmm/box.h>
#include <gtkmm/button.h>
#include <gtkmm/label.h>
#include <gtkmm/entry.h>
#include <gtkmm/scrolledwindow.h>
#include <gtkmm/drawingarea.h>

#include "Station.h"
#include "MeasurementChart.h"
#include "StationManager.h"
#include "ApiClient.h"
#include "AirQualityIndex.h"
class MainWindow : public Gtk::Window {
public:
    MainWindow();
    Station m_currentStation;


private:
    // Funkcje obsługujące GUI
    void on_button_show_all_clicked();
    void on_button_search_clicked();
    void on_button_confirm_clicked();
    void on_sensor_confirm_clicked();
    void on_button_back_clicked();
    void on_button_back_to_sensor_clicked();
    void on_back_to_station_clicked();  // Dodaj tę deklarację
    void on_back_to_station_list_clicked();  // Dodaj tę deklarację



    void showStationDetails(const Station& station);
    void showMainView();
    void clearChart(); //Funkcja czyszcząca wykres
    std::string toLower(const std::string& str);
    MeasurementChart m_chart;  // Wykres jako pole MainWindow (tworzony raz)
    Gtk::Box* m_chartInfoBox = nullptr;  // Box który zawiera info + wykres
    
    // Widok główny (lista stacji + wyszukiwanie)
    Gtk::Box m_box;              // Główny VBox
    Gtk::Box m_hbox;             // HBox dla pola i przycisku szukania
    Gtk::Entry m_entry;          // Pole na nazwę miasta
    Gtk::Button m_button_search; // Przycisk "Szukaj"
    Gtk::Button m_button_show_all; // Przycisk "Pokaż wszystkie"
    Gtk::ScrolledWindow m_scrolledWindow; // Scroll dla listy stacji
    Gtk::Label m_label;          // Label na listę stacji
    Gtk::Button m_button_back_to_station_list;

    Gtk::Entry m_idEntry;        // Pole na ID stacji
    Gtk::Button m_idConfirmButton; // Przycisk "Potwierdź" (ID stacji)

    Gtk::Button m_button_back_to_sensor;
    Gtk::Button m_button_back_to_station;

    int m_currentStationId = -1;  // Dodaj zmienną do przechowywania ID bieżącej stacji


    // Widok szczegółów stacji (sensory + wybór sensora)
    Gtk::Box m_stationBox;       // VBox dla widoku stacji
    Gtk::Label m_station_label;  // Nazwa stacji
    Gtk::Label m_stationInfoLabel; // Lista sensorów
    Gtk::ScrolledWindow m_stationScrolledWindow; // Scroll dla listy sensorów
    Gtk::Entry m_sensorEntry;    // Pole na ID sensora
    Gtk::Button m_sensorConfirmButton; // Przycisk "Potwierdź" (ID sensora)
    Gtk::Button m_button_back;   // Przycisk "Wróć"

    // Zarządzanie stacjami
    StationManager m_stationManager;
};

#endif // MAINWINDOW_H
