#include "MainWindow.h"
#include "ApiClient.h"
#include <sstream>
#include <algorithm>

MainWindow::MainWindow()
    : m_box(Gtk::ORIENTATION_VERTICAL),
      m_hbox(Gtk::ORIENTATION_HORIZONTAL),
      m_button_show_all("Wczytaj stacje"),
      m_button_search("Szukaj"),
      m_idConfirmButton("Potwierdź"),
      m_sensorConfirmButton("Potwierdź"),
      m_button_back("Wróć") {

    set_title("Monitor Jakości Powietrza");
    set_default_size(1200, 800);
    set_resizable(false);

    add(m_box);

    // Pole tekstowe i przycisk "Szukaj"
    m_entry.set_placeholder_text("Wpisz nazwę miejscowości");
    m_hbox.pack_start(m_entry, Gtk::PACK_EXPAND_WIDGET, 5);
    m_hbox.pack_start(m_button_search, Gtk::PACK_SHRINK, 5);

    // Pole na ID stacji
    m_idEntry.set_placeholder_text("Wpisz ID stacji");
    m_hbox.pack_start(m_idEntry, Gtk::PACK_SHRINK, 5);
    m_hbox.pack_start(m_idConfirmButton, Gtk::PACK_SHRINK, 5);

    m_box.pack_start(m_hbox, Gtk::PACK_SHRINK, 5);
    m_box.pack_start(m_button_show_all, Gtk::PACK_SHRINK, 5);

    // Konfiguracja przewijanego okna i labela
    m_scrolledWindow.add(m_label);
    m_scrolledWindow.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS);
    m_scrolledWindow.set_min_content_height(400);

    m_label.set_xalign(0.0);
    m_label.set_yalign(0.0);
    m_label.set_line_wrap(true);
    m_label.set_selectable(true);
    m_label.set_margin_top(5);
    m_label.set_margin_bottom(5);
    m_label.set_margin_start(5);
    m_label.set_margin_end(5);

    // Większa czcionka
    auto font = Pango::FontDescription("Sans 11");
    m_label.override_font(font);

    m_box.pack_start(m_scrolledWindow, Gtk::PACK_EXPAND_WIDGET, 5);

    // Podłączenie sygnałów
    m_button_show_all.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_button_show_all_clicked));
    m_button_search.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_button_search_clicked));
    m_idConfirmButton.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_button_confirm_clicked));

    show_all_children();
}

void MainWindow::on_button_show_all_clicked() {
    m_stationManager.loadStations("");
    std::vector<Station> stations = m_stationManager.getAllStations();

    std::ostringstream oss;
    for (const auto& station : stations) {
        oss << station.getName() << " (ID=" << station.getId() << ")" << "\n";
    }
    m_label.set_text(oss.str().empty() ? "Brak stacji!" : oss.str());
}

void MainWindow::on_button_search_clicked() {
    std::string cityInput = toLower(m_entry.get_text());
    m_stationManager.loadStations("");

    std::vector<Station> stations = m_stationManager.getAllStations();
    std::ostringstream oss;
    bool found = false;
    for (const auto& station : stations) {
        if (toLower(station.getCity()) == cityInput) {
            oss << station.getName() << " (ID=" << station.getId() << ")" << "\n";
            found = true;
        }
    }

    if (found) {
        m_label.set_text(oss.str());
    } else {
        m_label.set_text("Brak stacji w tej miejscowości!");
    }
}

void MainWindow::on_button_confirm_clicked() {
    std::string idText = m_idEntry.get_text();
    if (idText.empty() || !std::all_of(idText.begin(), idText.end(), ::isdigit)) {
        m_label.set_text("Wpisz poprawne ID (liczba)!");
        return;
    }

    int id = std::stoi(idText);
    std::vector<Station> stations = m_stationManager.getAllStations();
    auto it = std::find_if(stations.begin(), stations.end(), [id](const Station& s) {
        return s.getId() == id;
    });

    if (it != stations.end()) {
        showStationDetails(*it);
    } else {
        m_label.set_text("Nie znaleziono stacji o podanym ID. Spróbuj wczytac stacje");
    }
}

void MainWindow::showStationDetails(const Station& station) {
    remove();  // Usunięcie obecnego widoku

    m_currentStationId = station.getId();
    m_station_label.set_text("Stacja: " + station.getName() + " (" + std::to_string(station.getId()) + ")");
    m_station_label.set_xalign(0.0);
    m_station_label.set_margin_top(10);
    m_station_label.set_margin_bottom(10);
    m_station_label.set_margin_start(10);
    m_station_label.set_margin_end(10);

    m_chart.set_size_request(800, 400);  // np. szerokość i wysokość wykresu

    // Box który trzyma info i wykres
    m_chartInfoBox = Gtk::make_managed<Gtk::Box>(Gtk::ORIENTATION_HORIZONTAL);

    // Dodajemy etykietę i wykres
    m_chartInfoBox->pack_start(m_stationInfoLabel, Gtk::PACK_EXPAND_WIDGET, 5);
    m_chartInfoBox->pack_start(m_chart, Gtk::PACK_EXPAND_WIDGET, 5);

    // Dodajemy cały box do głównego kontenera
    m_stationBox.pack_start(*m_chartInfoBox, Gtk::PACK_EXPAND_WIDGET, 5);


    ApiClient apiClient;
    std::ostringstream oss;
    m_stationBox.pack_start(m_station_label, Gtk::PACK_SHRINK, 5);

    // === NOWY KOD: Pobieranie i wyświetlanie AirQualityIndex ===
    AirQualityIndex aqi = apiClient.getAirQualityIndex(station.getId());

    oss << "Indeks jakości powietrza (data: " << aqi.getCalcDate() << ")\n";
    oss << "Ogólny indeks: " << aqi.getStIndex() << "\n";
    oss << "SO2: " << aqi.getSo2Index() << "\n";
    oss << "NO2: " << aqi.getNo2Index() << "\n";
    oss << "PM10: " << aqi.getPm10Index() << "\n";
    oss << "PM2.5: " << aqi.getPm25Index() << "\n";
    oss << "O3: " << aqi.getO3Index() << "\n\n";
    
    auto sensors = apiClient.getSensors(station.getId());

    for (const auto& sensor : sensors) {
        oss << "Sensor ID: " << sensor["id"] << " - "
            << sensor["param"]["paramName"] << " (" << sensor["param"]["paramCode"] << ")\n";
    }

    m_stationInfoLabel.set_text(oss.str().empty() ? "Brak sensorów!" : oss.str());
    m_stationInfoLabel.set_xalign(0.0);
    m_stationInfoLabel.set_margin_top(5);
    m_stationInfoLabel.set_margin_bottom(5);
    m_stationInfoLabel.set_margin_start(5);
    m_stationInfoLabel.set_margin_end(5);

    m_stationScrolledWindow.add(m_stationInfoLabel);
    m_stationScrolledWindow.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS);
    m_stationScrolledWindow.set_min_content_height(400);

    // Zmniejszenie szerokości pola z wynikami pomiarów o 40%
    m_stationInfoLabel.set_size_request(-1, 40);  // Wysokość bez zmian, szerokość zmniejszona o 40%

    m_stationBox.pack_start(m_stationScrolledWindow, Gtk::PACK_EXPAND_WIDGET, 5);

    // Nowy poziomy box na pole i przyciski (kompaktowo)
    Gtk::Box* sensorBox = Gtk::make_managed<Gtk::Box>(Gtk::ORIENTATION_HORIZONTAL);

    // Pole tekstowe (stała szerokość, nie rozciąga się)
    m_sensorEntry.set_placeholder_text("Wpisz ID sensora");
    m_sensorEntry.set_size_request(60, -1);  // Szerokość 150px, wysokość automatyczna
    sensorBox->pack_start(m_sensorEntry, Gtk::PACK_SHRINK, 5);

    // Przycisk 'Potwierdź'
    m_sensorConfirmButton.set_label("Potwierdź");
    sensorBox->pack_start(m_sensorConfirmButton, Gtk::PACK_SHRINK, 5);

    // Przycisk 'Powrót do listy stacji' (wraca do listy stacji)
    m_button_back_to_station_list.set_label("Powrót do listy stacji");
    sensorBox->pack_start(m_button_back_to_station_list, Gtk::PACK_SHRINK, 5);

    // Połączenie przycisków z odpowiednimi funkcjami
    m_button_back_to_station.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_back_to_station_clicked));
    m_button_back_to_station_list.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_back_to_station_list_clicked));

    // Marginesy dla całego bloku
    sensorBox->set_margin_top(5);
    sensorBox->set_margin_bottom(5);
    sensorBox->set_margin_start(5);
    sensorBox->set_margin_end(5);

    m_stationBox.pack_start(*sensorBox, Gtk::PACK_SHRINK, 5);

    m_sensorConfirmButton.set_size_request(60, 30);
    m_button_back_to_station.set_size_request(60, 30);

    m_sensorConfirmButton.signal_clicked().connect(sigc::mem_fun(*this, &MainWindow::on_sensor_confirm_clicked));

    // Ustawienie domyślnych wymiarów okna
    set_default_size(1200, 800);  // Ustawienie wymiarów okna na 1800x900

    add(m_stationBox);
    show_all_children();
}




void MainWindow::on_sensor_confirm_clicked() {
    std::string idText = m_sensorEntry.get_text();
    if (idText.empty() || !std::all_of(idText.begin(), idText.end(), ::isdigit)) {
        m_stationInfoLabel.set_text("Wpisz poprawne ID sensora (liczba)!");
        return;
    }

    int sensorId = std::stoi(idText);

    ApiClient apiClient;

    // Pobieranie pomiarów z API dla sensora
    std::vector<Measurement> measurements = apiClient.getMeasurements(sensorId);
    m_chart.setMeasurements(measurements);

    // Wyświetlanie wyników pomiarów
    std::ostringstream oss;

    // --- Wstawienie informacji o parametrze ---
    int paramName = sensorId;
    oss << "Parametr: " << paramName << "\n";

    // --- Największy i najmniejszy pomiar ---
    if (!measurements.empty()) {
        Measurement maxMeasurement = m_chart.getMaxMeasurement();
        Measurement minMeasurement = m_chart.getMinMeasurement();

        oss << "Najwyższy pomiar: " << maxMeasurement.getValue() << " (Czas: " << maxMeasurement.getDate() << ")\n";
        oss << "Najniższy pomiar: " << minMeasurement.getValue() << " (Czas: " << minMeasurement.getDate() << ")\n";
        oss << "Średnia pomiarów: " << m_chart.getAverageValue() << ")\n";
        oss << "-----------------------------\n";

        for (const auto& measurement : measurements) {
            oss << "Pomiar: " << measurement.getValue() << " (Czas: " << measurement.getDate() << ")\n";
        }
    } else {
        oss << "Brak danych pomiarowych dla tego sensora.";
    }

    // Aktualizacja etykiety z informacjami o stacji
    m_stationInfoLabel.set_text(oss.str());

    // Tworzymy okno przewijania tylko dla wyników pomiarów
    Gtk::ScrolledWindow* scrolledWindow = Gtk::make_managed<Gtk::ScrolledWindow>();
    scrolledWindow->set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_ALWAYS);  // Włącz przewijanie

    // Tworzymy nową etykietę z wynikami pomiarów
    Gtk::Label* labelWithMeasurements = Gtk::make_managed<Gtk::Label>(oss.str());

    // Dodajemy etykietę do kontenera przewijania
    scrolledWindow->add(*labelWithMeasurements);

    // Tworzymy kontener poziomy
    Gtk::Box* horizontalBox = Gtk::make_managed<Gtk::Box>(Gtk::ORIENTATION_HORIZONTAL);

    // Kontener na wyniki pomiarów (z przewijaniem)
    Gtk::Box* leftBox = Gtk::make_managed<Gtk::Box>(Gtk::ORIENTATION_VERTICAL);
    // Kontener dla wykresu
    Gtk::Box* rightBox = Gtk::make_managed<Gtk::Box>(Gtk::ORIENTATION_VERTICAL);
    rightBox->pack_start(m_chart, Gtk::PACK_EXPAND_WIDGET, 5);  // Dodanie wykresu

    // Dodanie obu kontenerów do poziomego kontenera
    horizontalBox->pack_start(*leftBox, Gtk::PACK_SHRINK, 5);  // Lewa część (pomiar)
    horizontalBox->pack_start(*rightBox, Gtk::PACK_EXPAND_WIDGET, 5);  // Prawa część (wykres)

    // Dodanie poziomego kontenera do głównego okna
    m_stationBox.pack_start(*horizontalBox, Gtk::PACK_EXPAND_WIDGET, 5);

    // Upewnij się, że UI jest zaktualizowane
    show_all_children();
}






void MainWindow::on_button_back_to_sensor_clicked() {
    // Powrót do widoku wyboru sensora
    m_sensorEntry.set_text("");  // Wyczyść pole tekstowe
    showStationDetails(m_currentStation);  // Zatrzymanie na bieżącej stacji
}


void MainWindow::showMainView() {
    remove();  // Usunięcie widoku stacji
    add(m_box);
    show_all_children();
}

void MainWindow::on_button_back_clicked() {
    showMainView();
}

std::string MainWindow::toLower(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), [](unsigned char c) {
        return std::tolower(c);
    });
    return result;
}

void MainWindow::on_back_to_station_clicked() {
    if (m_currentStationId == -1) {
        m_stationInfoLabel.set_text("Brak wybranej stacji!");
        return;
    }

    ApiClient apiClient;

    // Pobierz dane pomiarów dla aktualnie wybranej stacji
    std::vector<Measurement> measurements = apiClient.getMeasurements(m_currentStationId);
    m_chart.setMeasurements(measurements);

    // Wyświetl dane stacji i pomiary
    std::ostringstream oss;
    oss << "Stacja: " << m_currentStationId << "\n";

    // Wstawienie danych pomiarowych
    if (!measurements.empty()) {
        Measurement maxMeasurement = m_chart.getMaxMeasurement();
        Measurement minMeasurement = m_chart.getMinMeasurement();

        oss << "Najwyższy pomiar: " << maxMeasurement.getValue() << " (Czas: " << maxMeasurement.getDate() << ")\n";
        oss << "Najniższy pomiar: " << minMeasurement.getValue() << " (Czas: " << minMeasurement.getDate() << ")\n";
        oss << "Średnia pomiarów: " << m_chart.getAverageValue() << ")\n";
        oss << "-----------------------------\n";

        for (const auto& measurement : measurements) {
            oss << "Pomiar: " << measurement.getValue() << " (Czas: " << measurement.getDate() << ")\n";
        }
    } else {
        oss << "Brak danych pomiarowych dla tego sensora.";
    }

    // Aktualizacja labeli z wynikami pomiarów
    m_stationInfoLabel.set_text(oss.str());

    // Odświeżenie widoku wykresu
    m_chart.show();
    m_chart.set_size_request(450, 300);  // Stała szerokość wykresu

    // Upewnij się, że UI jest zaktualizowane
    show_all_children();
}

void MainWindow::on_back_to_station_list_clicked()
{
    showMainView();
}