#include "Measurement.h"

// Konstruktor (inicjalizacja pola daty i wartości)
Measurement::Measurement(const std::string& date, double value)
    : date(date), value(value) {}

// Getter daty pomiaru
std::string Measurement::getDate() const {
    return date;
}

// Getter wartości pomiaru
double Measurement::getValue() const {
    return value;
}
