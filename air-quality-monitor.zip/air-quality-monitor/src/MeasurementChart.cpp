#include "MeasurementChart.h"
#include <algorithm>
#include <numeric>
#include <sstream>

MeasurementChart::MeasurementChart() {}
MeasurementChart::~MeasurementChart() {}

const double M_PI = 3.14159265358979323846;

void MeasurementChart::setMeasurements(const std::vector<Measurement>& measurements) {
    m_measurements = measurements;
    queue_draw();  // Odśwież wykres
}

Measurement MeasurementChart::getMaxMeasurement() const {
    if (m_measurements.empty()) return Measurement();  // Zwraca pusty obiekt, jeśli brak pomiarów

    // Znajduje pomiar o największej wartości
    return *std::max_element(m_measurements.begin(), m_measurements.end(),
        [](const Measurement& a, const Measurement& b) {
            return a.getValue() < b.getValue();
        });
}

Measurement MeasurementChart::getMinMeasurement() const {
    if (m_measurements.empty()) return Measurement();  // Zwraca pusty obiekt, jeśli brak pomiarów

    // Znajduje pomiar o najmniejszej wartości
    return *std::min_element(m_measurements.begin(), m_measurements.end(),
        [](const Measurement& a, const Measurement& b) {
            return a.getValue() < b.getValue();
        });
}

bool MeasurementChart::on_draw(const Cairo::RefPtr<Cairo::Context>& cr) {
    Gtk::Allocation allocation = get_allocation();
    double width = allocation.get_width();
    double height = allocation.get_height();

    // Tło
    cr->set_source_rgb(1.0, 1.0, 1.0);
    cr->paint();

    drawAxes(cr, width, height);
    drawLineChart(cr, width, height);

    return true;
}

void MeasurementChart::drawAxes(const Cairo::RefPtr<Cairo::Context>& cr, double width, double height) {
    cr->set_source_rgb(0, 0, 0);
    cr->set_line_width(2);

    // Oś X
    cr->move_to(40, height - 30);
    cr->line_to(width - 10, height - 30);
    cr->stroke();

    // Oś Y
    cr->move_to(40, height - 30);
    cr->line_to(40, 10);
    cr->stroke();
}

void MeasurementChart::drawLineChart(const Cairo::RefPtr<Cairo::Context>& cr, double width, double height) {
    if (m_measurements.empty()) return;

    // Granice
    auto minmax = std::minmax_element(m_measurements.begin(), m_measurements.end(),
        [](const Measurement& a, const Measurement& b) {
            return a.getValue() < b.getValue();
        });

    double minValue = minmax.first->getValue();
    double maxValue = minmax.second->getValue();
    if (minValue == maxValue) {
        minValue -= 1.0;
        maxValue += 1.0;
    }

    size_t count = m_measurements.size();
    double chartWidth = width - 60;
    double chartHeight = height - 50;

    // Skala
    double xStep = chartWidth / (count - 1);
    double yScale = chartHeight / (maxValue - minValue);

    // Linia wykresu
    cr->set_source_rgb(0.2, 0.4, 0.8);
    cr->set_line_width(2);

    for (size_t i = 0; i < count; ++i) {
        double x = 40 + i * xStep;
        double y = (height - 30) - ((m_measurements[i].getValue() - minValue) * yScale);

        if (i == 0)
            cr->move_to(x, y);
        else
            cr->line_to(x, y);
    }
    cr->stroke();

    // Punkty
    cr->set_source_rgb(0.8, 0.1, 0.1);
    for (size_t i = 0; i < count; ++i) {
        double x = 40 + i * xStep;
        double y = (height - 30) - ((m_measurements[i].getValue() - minValue) * yScale);
        cr->arc(x, y, 3, 0, 2 * M_PI);
        cr->fill();
    }


     double averageValue = getAverageValue();
     double avgY = (height - 30) - ((averageValue - minValue) * yScale);
 
     cr->set_source_rgb(1.0, 0.0, 0.0);  // Czerwona linia
     cr->set_line_width(1.5);
     cr->move_to(40, avgY);
     cr->line_to(width - 10, avgY);
     cr->stroke();
 
     // Opcjonalnie możesz podpisać średnią wartość (np. tekstem)
     cr->set_source_rgb(1.0, 0.0, 0.0);
     cr->select_font_face("Sans", Cairo::FONT_SLANT_NORMAL, Cairo::FONT_WEIGHT_BOLD);
     cr->set_font_size(12);
     std::ostringstream oss;
     oss.precision(2);
     oss << std::fixed << "Średnia: " << averageValue;
     cr->move_to(45, avgY - 5);
     cr->show_text(oss.str());
}

double MeasurementChart::getAverageValue() const {
    if (m_measurements.empty()) return 0.0;

    double sum = std::accumulate(m_measurements.begin(), m_measurements.end(), 0.0,
        [](double acc, const Measurement& m) {
            return acc + m.getValue();
        });
    return sum / m_measurements.size();
}